<?php
/**
 * Custom table caching before saving data
 *
 * @package    Meta Box
 * @subpackage MB Custom Table
 */

/**
 * Class MB_Custom_Table_Cache
 */
class MB_Custom_Table_Cache {

	/**
	 * Cached data. Each element in array is a row in database.
	 *
	 * @var array
	 */
	public static $rows = array();

	/**
	 * Get data from cache.
	 *
	 * @param int    $id     Row ID.
	 * @param string $table  Table name.
	 * @param string $column Column name.
	 *
	 * @return mixed|null
	 */
	public static function get( $id, $table, $column = null ) {
		$data = wp_cache_get( $id, self::get_cache_group( $table ) );

		if ( ! $data ) {
			return null;
		}

		// Return row data if column is not specific.
		if ( ! $column ) {
			return $data;
		}

		if ( ! isset( $data[ $column ] ) ) {
			return null;
		}

		return $data[ $column ];
	}

	/**
	 * Set cache data.
	 *
	 * @param int    $id     Row ID.
	 * @param string $table  Table name.
	 * @param string $column Column name.
	 * @param mixed  $data   Column data.
	 */
	public static function set( $id, $table, $column, $data ) {
		$row = self::get( $id, $table );
		if ( ! $row ) {
			$row = array();
		}

		$row[ $column ] = $data;
		self::set_row( $id, $table, $row );
	}

	/**
	 * Set a row to cache.
	 *
	 * @param int    $id    Row ID.
	 * @param string $table Table name.
	 * @param array  $data  Row data.
	 */
	public static function set_row( $id, $table, $data ) {
		wp_cache_set( $id, $data, self::get_cache_group( $table ) );
	}

	/**
	 * Get cache group name from table name.
	 *
	 * @param string $table Table name.
	 *
	 * @return string
	 */
	protected static function get_cache_group( $table ) {
		return "rwmb_{$table}_table_data";
	}
}
