<?php
/**
 * Loader class
 *
 * @package    Meta Box
 * @subpackage MB Custom Table
 */

/**
 * Class MB_Custom_Table_Loader
 */
class MB_Custom_Table_Loader {

	public function init() {
		add_filter( 'rwmb_get_storage', array( $this, 'filter_storage' ), 10, 3 );
		add_action( 'rwmb_after_save_post', array( $this, 'update_from_cache' ) );
	}

	/**
	 * Filter storage object.
	 *
	 * @param RWMB_Table_Storage $storage     Custom table storage object.
	 * @param string             $object_type Object type.
	 * @param RW_Meta_Box        $meta_box    Meta box object.
	 *
	 * @return mixed
	 */
	public function filter_storage( $storage, $object_type, $meta_box ) {
		if ( $meta_box && $this->is_custom_table( $meta_box ) ) {
			$storage = new RWMB_Table_Storage();
			$storage->set_table( $meta_box->table );
		}

		return $storage;
	}

	/**
	 * Check if meta box uses custom table.
	 *
	 * @param RW_Meta_Box $meta_box Meta box object.
	 *
	 * @return bool
	 */
	protected function is_custom_table( $meta_box ) {
		return 'custom_table' === $meta_box->storage_type && ! empty( $meta_box->meta_box['table'] );
	}

	/**
	 * Update data from cache.
	 *
	 * @param int $object_id Object ID.
	 */
	public function update_from_cache( $object_id ) {
		$meta_boxes = rwmb_get_registry( 'meta_box' )->all();

		foreach ( $meta_boxes as $meta_box ) {
			if ( ! $this->is_custom_table( $meta_box ) ) {
				return;
			}

			$storage = $meta_box->get_storage();
			$row = MB_Custom_Table_Cache::get( $object_id, $meta_box->table );

			// Serialize array value.
			$saved_data = array();
			foreach ( $row as $key => $value ) {
				$saved_data[ $key ] = is_array( $value ) ? maybe_serialize( $value ) : $value;
			}

			if ( $storage->row_exists( $object_id ) ) {
				$storage->update_row( $object_id, $saved_data );
			} else {
				$storage->insert_row( $object_id, $saved_data );
			}
		}
	}
}
