<?php

new MBB_Date;